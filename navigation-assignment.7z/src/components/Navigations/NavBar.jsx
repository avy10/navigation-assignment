import { NavLink } from "react-router-dom";
import { NAVIGATIONS } from "../../assets/utils/navigations";
import styles from "./NavBar.module.css"
import { useState } from "react";
const NavBar = () => {
    const [selectedNav, setSelectedNav] = useState("MyInbox");
    function updateSelectedNav(newValue){
        setSelectedNav(newValue)
    }
    return (
        <nav>
            <ul className={`${styles.navigations} `}>
                {NAVIGATIONS.map((ele, ind) => (
                    <li key={ind} 
                        className={selectedNav === ele ? styles.isActive : "" } 
                        id={ele == "COOP" ? styles.coop : ""} 
                        onClick={()=>updateSelectedNav(ele)}
                    >
                        <NavLink to={`/${ele}`} 
                            // className={({isActive})=> isActive ? styles.isActive : '' }
                        >{ele}</NavLink>
                    </li>
                ))}
            </ul>
            <div className={styles.selection}>
                <span>Select Office</span>
                <select>
                    {Array.from({length: 20}, (_, i) => i + 1).map(ele => (
                         <option key={ele}>{ele}</option>
                    ))}
                   
                </select>
            </div>
        </nav>
    );
};

export default NavBar;
