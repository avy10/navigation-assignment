import { useEffect } from "react";

const DefaultNavPage = ({pageName}) => {
   
    return (
        <div>{pageName}</div>
    )
}

export default DefaultNavPage;