export const NAVIGATIONS = [
    "MyInbox",
    "Watchlist",
    "OfficeInbox",
    "Workload",
    "Dashboards",
    "Notifications",
    "Search",
    "COOP",
    "Admin",
    "Support",
    "Reports",
    "TestData"
]