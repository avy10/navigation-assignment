import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Header from './components/Header/Header'
import { BrowserRouter, Navigate, Route , Routes} from 'react-router-dom'
import DefaultNavPage from './components/Navigations/DefaultNavPage'
import { NAVIGATIONS } from './assets/utils/navigations'
import NavBar from './components/Navigations/NavBar'
const App = () => {
 

  return (
    <>
      <Header />
      <BrowserRouter>
        <NavBar />
        <Routes>
          <Route path="/" element={<Navigate to={"/MyInbox"} />} />
          {NAVIGATIONS.map((ele, ind) => (
            <Route key={ind} path={`/${ele}`} element={<DefaultNavPage pageName={`${ele}`}  />} />
          ))}
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
